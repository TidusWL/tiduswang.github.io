# Wiki Log

> 所有 wiki 操作的按时间顺序记录。仅追加。
> 格式：`## [YYYY-MM-DD] action | subject`
> 操作：ingest, update, query, lint, create, archive, delete
> 超过 500 条时轮转：重命名为 log-YYYY.md，重新开始。

## [2026-05-21] create | Wiki initialized
- Domain: 个人综合知识库（技术/编程/AI、综合笔记、工作项目、其他）
- 结构创建完成：SCHEMA.md, index.md, log.md
- 目录结构：raw/{articles,papers,transcripts,assets}, entities/, concepts/, comparisons/, queries/

## [2026-05-23] create | opening-premium-rate
- 新增概念页：开盘溢价率与涨停股次日操作策略
- 来源：视频分享
- 标签：finance, stock, trading, tutorial
- 文件：concepts/opening-premium-rate.md

## [2026-05-26] lint | 首次 wiki 健康检查
- 运行完整的 wiki lint
- **总页面数**: 7
- **发现问题**: 11个
  - 🔴 孤立页面 3 个：rock-paper-scissors, blackjack-strategy, opening-premium-rate（无入链）
  - 🟡 缺失交叉引用：无
  - 🟠 缺少来源 1 个：probability-in-gaming.md（sources 为空）
  - 🟠 索引不同步 7 个：所有页面均未在 index.md 列出
- **修复**:
  - 更新 index.md，补全所有页面索引
  - probability-in-gaming.md 添加 sources: [scratch]
  - rock-paper-scicillin.md 添加互链 [[blackjack-strategy]]
  - probability-in-gaming.md 添加互链到 blackjack-strategy, poker-probability, rock-paper-scissors, sports-betting-ev

## [2026-05-26] update | SCHEMA.md
- 新增 Summary 页面类型定义（summaries/ 目录）
- 新增 Operations 章节（Ingest / Query / Lint）
- 新增 Lint 规则（孤立页面、过期声明、缺失交叉引用、矛盾检查、空来源、索引同步）

## [2026-05-26] create | probability-gaming-summary
- 新增领域总览页：概率博弈知识体系总览
- 链接到所有 7 个相关概念页
- 包含：领域概述、核心知识地图、思维框架、开放问题、推荐阅读顺序
- 文件：summaries/probability-gaming-summary.md

## [2026-05-26] create | summaries/ 目录
- 新建 summaries/ 目录，用于存放领域总览页

## [2026-05-26] lint | 修复后验证
- 修复后再次运行 lint，所有检查通过 ✅
- 孤立页面：0 → 全部修复
- 索引同步：全部修复
- 空来源：全部修复
- 总页面数：8（7 concept + 1 summary）

## [2026-06-03] ingest | Harness 架构体系
- 来源1：36氪《一文读懂Harness Engineering》→ raw/articles/harness-engineering-36kr-2026.md
- 来源2：腾讯云《一文讲透如何构建Harness——六大组件全解析》→ raw/articles/harness-six-components-tencent-2026.md
- 创建概念页：concepts/harness-architecture.md（Harness架构体系总览）
- 创建概念页：concepts/harness-context-reset.md（Context Reset机制）
- 创建概念页：concepts/mcp-protocol.md（MCP协议）
- 创建对比页：comparisons/harness-vs-framework.md（Harness vs Framework）
- 更新 index.md，新增 4 个页面索引
- 标签：ai, ml, system-design, framework, open-source, protocol, context-management, comparison
- 总页面数：12
