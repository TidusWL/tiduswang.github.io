# Wiki Index

> 内容目录。每个 wiki 页面按类型列出，附一行摘要。
> 先读这里来找到相关页面。
> Last updated: 2026-06-03 | Total pages: 12

## Summaries

- [[probability-gaming-summary]] — 概率论与竞技博弈知识体系总览

## Concepts

- [[probability-in-gaming]] — 概率论在竞技博弈中的应用（基础概率、贝叶斯、期望值、分布模型、蒙特卡洛）
- [[monte-carlo-simulation]] — 蒙特卡洛模拟在博弈中的应用（随机抽样、赛事模拟、精度分析）
- [[blackjack-strategy]] — 21点基本策略与算牌法（基本策略表、高低法计数）
- [[poker-probability]] — 德州扑克概率分析（听牌概率、底池赔率、隐含赔率）
- [[rock-paper-scissors]] — 石头剪刀布博弈策略（纳什均衡、人类行为偏差、利用策略）
- [[sports-betting-ev]] — 体育博彩期望值与凯利公式（EV分析、资金管理）
- [[opening-premium-rate]] — 开盘溢价率与涨停股次日操作策略
- [[harness-architecture]] — Harness 架构体系：AI Agent 运行时控制框架（六大组件、三层架构、Anthropic/OpenAI 实践）
- [[harness-context-reset]] — Context Reset 上下文重置机制（长程任务的交接协议）
- [[mcp-protocol]] — MCP 协议：AI 模型与外部工具的标准化交互方式

## Entities
<!-- 按字母排序 -->

## Comparisons

- [[harness-vs-framework]] — Harness vs Framework 架构范式对比

## Queries
<!-- 按字母排序 -->
